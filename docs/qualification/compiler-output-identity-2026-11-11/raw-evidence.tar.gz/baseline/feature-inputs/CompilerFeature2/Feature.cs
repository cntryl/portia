using Cntryl.Portia;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;
namespace CompilerFeature2;
[Discriminator("compiler.feature2.event", 2)]
public sealed record FeatureEvent(int Value) : DomainEvent;
public sealed class FeatureUpcaster : IJsonDomainEventUpcaster
{
    public string EventName => "compiler.feature2.event";
    public int FromVersion => 1;
    public JsonObject Upcast(JsonObject json) { json["Value"] = 1; return json; }
}
[PortiaJsonContext, JsonSerializable(typeof(FeatureEvent))]
public sealed partial class FeatureJsonContext : JsonSerializerContext;