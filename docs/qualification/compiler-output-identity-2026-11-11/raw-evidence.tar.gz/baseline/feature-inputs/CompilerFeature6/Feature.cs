using Cntryl.Portia;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;
namespace CompilerFeature6;
[Discriminator("compiler.feature6.event", 2)]
public sealed record FeatureEvent(int Value) : DomainEvent;
public sealed class FeatureUpcaster : IJsonDomainEventUpcaster
{
    public string EventName => "compiler.feature6.event";
    public int FromVersion => 1;
    public JsonObject Upcast(JsonObject json) { json["Value"] = 1; return json; }
}
[PortiaJsonContext, JsonSerializable(typeof(FeatureEvent))]
public sealed partial class FeatureJsonContext : JsonSerializerContext;