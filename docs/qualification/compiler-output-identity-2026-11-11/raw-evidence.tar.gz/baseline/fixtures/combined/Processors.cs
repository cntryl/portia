using System; using System.Threading; using System.Threading.Tasks; using Cntryl.Portia;
namespace CompilerFixtures;
public sealed partial class BenchmarkProjector : Projector, IProjectorHandler<ProcessorEvent>
{ public BenchmarkProjector() : base(null!, EventStreamPattern.ForPattern("events")) { } public ValueTask<Result> HandleAsync(IProjectorContext<ProcessorEvent> context, CancellationToken ct) => ValueTask.FromResult(Result.Success); }
public sealed partial class BenchmarkReactor : Reactor, IReactorHandler<ProcessorEvent>
{ public BenchmarkReactor() : base(null!, EventStreamPattern.ForPattern("events")) { } public ValueTask<Result> HandleAsync(IReactorContext<ProcessorEvent> context, CancellationToken ct) => ValueTask.FromResult(Result.Success); }
